<template>
  <div class="d-flex flex-column fv-row">
    <label v-if="label" class="d-flex align-items-center fs-6 fw-semibold mb-2">
      <span :class="required ? 'required' : ''">{{ label }}</span>
      <i
        v-if="tooltip"
        class="fas fa-exclamation-circle ms-2 fs-7"
        data-bs-toggle="tooltip"
        title="Specify a target name for future usage and reference"
      ></i>
    </label>

    <el-form-item class="mb-0" prop="targetTitle" :size="size">
      <el-input
        v-model="internalValue"
        :type="type"
        :placeholder="placeholder"
        :disabled="disabled"
        :readonly="readonly"
        @input="handleInput"
      ></el-input>
    </el-form-item>
  </div>
</template>

<script setup lang="ts">
import { defineProps, defineEmits, ref, watch } from "vue";

interface propsType {
  modelValue: string | number;
  type?: "text" | "password" | "email" | "number";
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  label?: string;
  tooltip?: string;
  size?: "large" | "default" | "small";
}
const emit = defineEmits(["update:modelValue"]);
const props = defineProps<propsType>();
const internalValue = ref(props.modelValue);

const handleInput = (value: string | number) => {
  internalValue.value = value;
  // Сообщаем родительскому компоненту об изменении значения
  emit("update:modelValue", value);
};

// Следим за изменениями в пропсе modelValue и обновляем внутреннее значение
watch(
  () => props.modelValue,
  (newValue) => {
    internalValue.value = newValue;
  }
);
</script>

<template>
  <div class="d-flex mb-7">
    <button
      href="#"
      class="btn btn-sm w-100"
      :class="{ 'btn-primary': modelValue, 'btn-secondary': !modelValue }"
      style="margin-right: 10px"
      @click="handleClick(1)"
    >
      Да
    </button>
    <button
      href="#"
      class="btn btn-sm w-100"
      :class="{ 'btn-danger': !modelValue, 'btn-secondary': modelValue }"
      @click="handleClick(0)"
    >
      Нет
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, defineProps, watch } from "vue";
interface propsType {
  modelValue: string | number;
}
const emit = defineEmits(["update:modelValue"]);
const props = defineProps<propsType>();
const internalValue = ref(props.modelValue);

const handleClick = (value) => {
  emit("update:modelValue", value);
};

watch(
  () => props.modelValue,
  (newValue) => {
    internalValue.value = newValue;
  }
);
</script>

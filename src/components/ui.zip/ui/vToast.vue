<template>
  <div>
    <button @click="showToast">Показать уведомление</button>

    <div v-if="isToastVisible" class="toast">
      <div class="toast-header">
        {{ toastTitle }}
        <button
          @click="hideToast"
          type="button"
          class="close"
          data-dismiss="toast"
          aria-label="Close"
        >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="toast-body">
        {{ toastMessage }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isToastVisible: false,
      toastTitle: "Уведомление",
      toastMessage: "Это ваше уведомление.",
    };
  },
  methods: {
    showToast() {
      this.isToastVisible = true;
      setTimeout(() => {
        this.isToastVisible = false;
      }, 3000); // Закрываем уведомление через 3 секунды
    },
    hideToast() {
      this.isToastVisible = false;
    },
  },
};
</script>

<style scoped>
/* Стили для всплывающего уведомления */
.toast {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 5px;
  padding: 10px;
  max-width: 300px;
  animation: fadeInUp 0.5s, fadeOut 0.5s 2.5s forwards;
}

@keyframes fadeInUp {
  from {
    transform: translate3d(0, 50px, 0);
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
</style>

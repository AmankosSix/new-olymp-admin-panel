<template>
  <div class="autocomplete-container mb-7 w-100" ref="autocompleteContainer">
    <el-autocomplete
      class="w-100"
      v-model="propModel"
      :fetch-suggestions="querySearch"
      placeholder="Введите здесь"
      @select="handleSelect"
      @focus="getCatalogList"
      value-key="title"
    >
      <template #default="{ item }">
        {{ item.title }}
      </template></el-autocomplete
    >
  </div>
</template>

<script lang="ts">
import { ref, watch, onMounted } from "vue";

import ApiService from "@/core/services/ApiService";
export default {
  name: "CCatalogList",
  props: {
    modelValue: {
      type: [String, Number, Object, Array],
      default: () => null,
    },
    item: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup(props, { emit }) {
    const propModel = ref(null);
    const title = ref("");
    const config = ref({
      page: 1,
      total: 0,
      list: [],
    });
    const autocompleteContainer = ref(null);
    const firstRender = ref(false);
    let timeReq: ReturnType<typeof setTimeout> | undefined = undefined;
    const querySearch = (queryString: string, cb: any) => {
      clearTimeout(timeReq);
      if (!firstRender.value) {
        firstRender.value = true;
        cb(config.value.list);
        return;
      }
      timeReq = setTimeout(async () => {
        title.value = queryString;
        await getCatalogList({
          page: 1,
          title: title.value,
          eventSearch: true,
        });
        cb(config.value.list);
      }, 800);
    };
    // const createFilter = (queryString: string) => {
    //   return (el) => {
    //     return el.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
    //   };
    // };

    const inputList = async (input) => {};

    // const endIntersect = async (entries, observer, isIntersecting) => {
    //   if (isIntersecting && config.value.list?.length < config.value.total) {
    //     await getCatalogList({
    //       page: config.value.page + 1,
    //       title: title.value,
    //     });
    //   }
    // };

    watch(
      () => props.modelValue,
      async (val, old) => {
        if (val && !old) {
          await getCatalogList({
            page: 1,
            title: val,
            eventSearch: false,
          });
          propModel.value = propModel.value = config.value.list.filter(
            (el) => el.id == props.modelValue
          );
          propModel.value = propModel.value.length
            ? propModel.value[0].title
            : null;
        }
      }
    );

    onMounted(async () => {
      if (!config.value.list.length) {
        await getCatalogList();
      }
    });

    const handleSelect = (item) => {
      propModel.value = item.title;
      emit("update:modelValue", item.id);
    };
    const getCatalogList = async ({
      page = 1,
      title = "",
      eventSearch = false,
    } = {}) => {
      await ApiService.get(
        "/api/" + (props.item?.url ? props.item?.url : "categorieslist"),
        {
          params: {
            page: page,
            title: props.modelValue && !eventSearch ? props.modelValue : title,
          },
        }
      ).then((res) => {
        config.value.list = eventSearch
          ? res.data.data
          : [...config.value.list, ...res.data.data];
        config.value.page = res.data.meta?.page ? res.data.meta.page : 1;
        config.value.total = res.data.meta?.total ? res.data.meta.total : 1000;
      });
    };
    return {
      propModel,
      querySearch,
      props,
      //   inputList,
      config,
      getCatalogList,
      handleSelect,
      //   endIntersect,
    };
  },
};
</script>

<style>
.autocomplete-container {
  max-height: 200px; /* или другая желаемая высота */
  overflow-y: auto;
}
</style>

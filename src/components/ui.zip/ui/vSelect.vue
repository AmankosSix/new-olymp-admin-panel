<template>
  <div class="mb-7">
    <label v-if="item.label" :class="['fs-6', 'fw-semibold', 'mb-2']">{{
      item.label
    }}</label>
    <select
      v-model="propModel"
      :name="item.name"
      :class="['form-select', 'form-select-solid']"
      @change="handleChange"
    >
      <option :value="placeholderValue" disabled>
        {{ item.placeholder || "Выбрать..." }}
      </option>
      <option v-for="option in items" :key="option.id" :value="option.id">
        {{ option.title }}
      </option>
    </select>
  </div>
</template>

<script>
import { ref, watch, onMounted } from "vue";
import ApiService from "@/core/services/ApiService";
export default {
  name: "VSelect",

  props: {
    item: {
      type: Object,
      default() {
        return {};
      },
    },
    items: {
      type: Array,
      default() {
        return [];
      },
    },
    modelValue: {
      type: [String, Number, Object, Array],
      default: () => null,
    },
  },
  setup(props, { emit }) {
    const propModel = ref(props.modelValue);

    const handleChange = () => {
      emit("update:modelValue", propModel.value);
    };

    watch(
      () => props.modelValue,
      (newValue) => {
        propModel.value = newValue;
      }
    );
    return {
      propModel,
      handleChange,
    };
  },
};
</script>
